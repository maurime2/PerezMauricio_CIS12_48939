<html>
  <head>
    <title>Solo For Loop!</title>
  </head>
  <body>
    <p>
      <?php
      // Write your for loop below!
      for($i=10; $i<=100; $i = $i+10){
          echo $i . "<br/>";
          //echo "<br/>";
          }
      ?>
    </p>
  </body>
</html>