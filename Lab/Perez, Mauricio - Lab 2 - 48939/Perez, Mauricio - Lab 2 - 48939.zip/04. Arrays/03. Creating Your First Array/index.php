<html>
  <head>
    <title>My First Array</title>
  </head>
  <body>
    <p>
      <?php
      $friends  = array("Mauri", "Kathy", "Ben"); 
      ?>
    </p>
  </body>
</html>