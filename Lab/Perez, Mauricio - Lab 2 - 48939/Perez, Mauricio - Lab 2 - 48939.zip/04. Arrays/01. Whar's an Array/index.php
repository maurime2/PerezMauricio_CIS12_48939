<html>
  <head>
    <title>Woot, Arrays!</title>
  </head>
  <body>
    <?php
      $array = array("Egg", "Tomato", "Beans");
    ?>    
  </body>
</html>