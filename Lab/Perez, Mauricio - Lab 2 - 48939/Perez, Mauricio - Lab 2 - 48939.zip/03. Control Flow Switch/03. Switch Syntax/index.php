<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
	<body>
    <?php
    $fruit = "Apple";
    
    switch ($fruit) {
        case 'Apple':
            echo "Yummy.";
            break;
       default:
        echo "None of the above";;
    }
    
    ?>
    </body>
</html>