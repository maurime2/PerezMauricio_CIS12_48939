<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
	<body>
    <?php
    switch (3) {
        case 0:
            echo 'The value is 0';
            break;
        case 1:
            echo 'The value is 1';
            break;
        case 2:
            echo 'The value is 2';
            break;
        default:
            echo "The value isn't 0, 1 or 2";
    }
    ?>
    </body>
</html>