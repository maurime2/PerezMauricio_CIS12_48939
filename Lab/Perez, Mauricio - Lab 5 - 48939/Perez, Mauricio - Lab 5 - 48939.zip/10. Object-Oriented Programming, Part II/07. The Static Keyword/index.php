<html>
  <head>
    <title></title>
  </head>
  <body>
    <p>
      <?php
        class King {
          // Modify the code on line 10...
          public static function proclaim() {
            echo "A kingly proclamation!";
          }//Function Proclaim
        }//Class King ENds
        // ...and call the method below!
        King::proclaim();
      ?>
    </p>
  </body>
</html>