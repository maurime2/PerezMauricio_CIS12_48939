<html>
  <head>
    <title>OOP Review</title>
  </head>
  <body>
    <p>
      <?php
      // Create a Person class here:
      class Person{
          
        }
      
      // And create a Person instance called $me here:
      $me = new Person(); 
      
      ?>
    </p>
  </body>
</html>