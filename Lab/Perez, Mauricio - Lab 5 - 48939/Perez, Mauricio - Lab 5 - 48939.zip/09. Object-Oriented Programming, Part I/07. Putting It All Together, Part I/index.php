<!DOCTYPE html>
<html>
	<head>
	  <title> Practice makes perfect! </title>
      <link type='text/css' rel='stylesheet' href='style.css'/>
	</head>
	<body>
      <p>
    <?php
        //<!-- Your code here -->
        class Dog {
            //Public Properties
            public $numLegs = 4;
            public $name ;
            
            // Assigning the values
            public function __construct($name) {
              $this->name = $name;
            }//End Constructor
                
            //Methods
            public function bark(){
                
            }//End function bark()
            
            public function greet(){
                
            }//End function greet()
            
        }//End Class Dog  
            
            
    ?>
      </p>
    </body>
</html>