<!DOCTYPE html>
<html>
	<head>
	  <title>Reconstructing the Person Class</title>
      <link type='text/css' rel='stylesheet' href='style.css'/>
	</head>
	<body>
      <p>
    <?php
        //<!-- Your code here -->
        class Person {
          
        }
        
        $teacher = new Person();
        $student = new Person();
    ?>
      </p>
    </body>
</html>