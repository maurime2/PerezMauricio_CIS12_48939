<html>
	<head>
		<title></title>
	</head>
	<body>
      <?php
    function returnName ()
    {
            $name = "Mauricis S. Perez";
            return $name;
    }
    
    $test = returnName();
    echo $test;
      ?>
    </body>
</html>