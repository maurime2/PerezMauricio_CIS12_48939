<html>
    <head>
		<title></title>
	</head>
	<body>
      <p>
        <?php
          echo strlen("Mauricio");
          
        ?>
      </p>
    </body>
</html>