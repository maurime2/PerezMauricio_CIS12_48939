<html>
	<head>
		<title></title>
	</head>
	<body>
      <p>
        <?php
        // Write your function below!
        function displayName() {
             $name = "Mauricis S. Perez";
            echo $name;
          }
        
       
        displayName();
        
        ?>
      </p>
    </body>
</html>