<html>
  <p>
    <?php
    // Get the length of your own name
    // and print it to the screen!
    $length = strlen("Mauricio");
    print $length;
    ?>
  </p>
</html>