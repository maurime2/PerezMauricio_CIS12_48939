<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
        <p>
          <?php
              echo 5 * 7;
          ?>
        </p>
	</body>
</html>