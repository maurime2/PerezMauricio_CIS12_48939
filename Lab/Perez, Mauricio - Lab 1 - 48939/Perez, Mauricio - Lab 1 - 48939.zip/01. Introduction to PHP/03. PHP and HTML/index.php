<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
        <p>
          <?php
                echo "I'm Learning PHP";
          ?>
        </p>   
	</body>
</html>