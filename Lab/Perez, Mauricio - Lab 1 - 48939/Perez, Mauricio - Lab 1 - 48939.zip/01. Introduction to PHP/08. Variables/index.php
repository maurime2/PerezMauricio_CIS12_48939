<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
	    <p>
	      <?php
	        $myName = "Mauricio";
	        $ myAge = 28;
	      ?>
	    </p>
    </body>
</html>