<!DOCTYPE html>
<html>
	<head>
	</head>
	<body>
        <p>
          <?php
            echo "This is my String!";
          ?>
        </p>
	</body>
</html>