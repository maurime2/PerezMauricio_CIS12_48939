<!DOCTYPE html>
<html>
	<head>
		<title>Oh No!</title>
	</head>
	<body>
        <p><?php
            echo "Oh, the humanity!"; // COMENT GOES HERE
          ?></p>
    </body>
</html>