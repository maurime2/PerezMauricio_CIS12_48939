<html>
  <head>
    <title>Comparing Numbers</title>
  </head>
  <body>
    <p>
      <?php
        1 < 9;
      ?>
    </p>
  </body>
</html>