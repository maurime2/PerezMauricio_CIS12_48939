<html>
  <head>
  </head>
  <body>
    <p>
      <?php
        // Write your if/elseif/else statement here!
        $name = "Mauricio";
        if($name == "Paul"){
            echo "The condition is true";
            }
            
        else{
            print "The condition is false";
            }    
      ?>
    </p>
  </body>
</html>